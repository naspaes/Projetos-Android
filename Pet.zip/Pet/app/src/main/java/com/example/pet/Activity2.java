package com.example.pet;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Activity2 extends AppCompatActivity {

    TextView nome;
    //TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        nome = (TextView) findViewById(R.id.textNome);
        Bundle bundle = getIntent().getExtras();
        String data = bundle.getString("nome");

        nome.setText("Olá " + data);

        String string = "Sem extras";

        if(bundle != null ){
            string = bundle.getString("key");
            if(string == null){
                string = "Não tem name com o valor key";
            }
        }

       // textView = findViewById(R.id.textView);
       // textView.setText(string);

       // Intent intentResult = new Intent();
       // intentResult.putExtra("keyResult","Esta é uma string de retorno");
       // setResult(RESULT_OK, intentResult);


    }
}