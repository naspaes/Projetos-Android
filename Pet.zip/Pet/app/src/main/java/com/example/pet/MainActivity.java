package com.example.pet;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText nome;
    Button cadastrar;
    //TextView textView;
    //int REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nome = (EditText) findViewById(R.id.edtNome);
        cadastrar = (Button) findViewById(R.id.btnCadastrar);


        cadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nomePet = nome.getText().toString();
                Bundle bundle = new Bundle();
                bundle.putString("nome", nomePet);
                Intent in = new Intent(MainActivity.this, Activity2.class);
                in.putExtras(bundle);
                startActivity(in);
            }
        });
    }


    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                assert data != null;
                String stringResult = data.getStringExtra("keyResult");
                textView.setText(stringResult);
            }
        }

   } */
}
